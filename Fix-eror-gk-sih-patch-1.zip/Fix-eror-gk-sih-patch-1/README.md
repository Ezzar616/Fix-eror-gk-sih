<div align="center">
<img src="https://telegra.ph/file/4637101da58e21976363b.jpg" alt="AhmdLuiï¿½" width="300" />

</p>
<h1 align="center">versi fix eror dari sc bot md gweh</h1>

<h1 align="center">Jangan lupa kasih stars & follow :)</h1>

>
>
>
</div>
<p align="center">
  <a href="https://github.com/Luigmntng"><img title="Author" src="google.com" /></a>
  <h4 align="center">
  <a
  <a href="https://wa.me/6282146092695">SC FREE API KOK GAN >//< </a>
</h4>
</p>

## CARA INSTALL DI TERMUX
```bash
> termux-setup-storage
> pkg update && pkg upgrade
> pkg install git
> pkg install nodejs
> pkg install bash
> pkg install ffmpeg
> pkg install libwebp
> git clone https://github.com/Luigmntng/Fix-eror-gk-sih
> cd Fix-eror-gk-sih
> npm i
> node index
# Untuk Sdcard (File Sudah Di Download)
> cd /sdcard
> cp -r Fix-eror-gk-sih $HOME
> cd Fix-eror-gk-sih
> npm i
> node index
```

# Run On Heroku

Simple wa md

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Luigmntng/SoikemV2)



# tidak bisa Ambil [seesion.data.json] jadi ambil sendiri di sc bot md lainnya ygy

[![Run on google](https://google.com)



# Heroku Buildpack

| BuildPack | LINK |
|--------|--------|
| **FFMPEG** |[here](https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest) |
| **IMAGEMAGICK** | [here](https://github.com/DuckyTeam/heroku-buildpack-imagemagick) |
| **Node.js [salin]**     | heroku/nodejs|


# THANKS TO 
 [`Baileys`](https://github.com/adiwajshing/Baileys)

 [`AhmdLui`](https://wa.me/6282146092695)

# Hargai Kami Dengan Menambahkan Kredit ( Wm ) 

~ Selamat Memakai~







 [![AhmdLui](https://github.com/AlyaaXd.png?size=100)](https://github.com/Luigmntng) 

[AhmdLui](https://github.com/Luigmntng) 
 Creator 

